import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FanExperienceGUI extends JFrame {
private GameData gameData;
private GameStatistics gameStatistics;
private JLabel homeScoreLabel;
private JLabel awayScoreLabel;
private JLabel gameTimeLabel;
private JLabel locationLabel;
private JLabel homeShotsOnGoalLabel;
private JLabel awayShotsOnGoalLabel;
private JLabel homePossessionLabel;
private JLabel awayPossessionLabel;
private JLabel homeCornersLabel;
private JLabel awayCornersLabel;

private JPanel commentaryPanel;
private JPanel highlightsPanel;

public FanExperienceGUI(GameData gameData, GameStatistics gameStatistics) {
    this.gameData = gameData;
    this.gameStatistics = gameStatistics;

    // Initialize labels
    homeScoreLabel = new JLabel("Home: " + gameData.getHomeTeamScore());
    awayScoreLabel = new JLabel("Away: " + gameData.getAwayTeamScore());
    gameTimeLabel = new JLabel("Time: " + gameData.getGameTimeInSeconds() + " seconds");
    locationLabel = new JLabel("Location: " + gameData.getGameLocation());
    homeShotsOnGoalLabel = new JLabel("Shots on Goal: Home - " + gameStatistics.getHomeTeamShotsOnGoal());
    awayShotsOnGoalLabel = new JLabel("Away - " + gameStatistics.getAwayTeamShotsOnGoal());
    homePossessionLabel = new JLabel("Possession: Home - " + gameStatistics.getHomeTeamPossession() + "%");
    awayPossessionLabel = new JLabel("Away - " + gameStatistics.getAwayTeamPossession() + "%");
    homeCornersLabel = new JLabel("Corners: Home - " + gameStatistics.getHomeTeamCorners());
    awayCornersLabel = new JLabel("Away - " + gameStatistics.getAwayTeamCorners());

    // Initialize commentary panel
    commentaryPanel = new JPanel();
    JButton generateCommentaryButton = new JButton("Generate Live Commentary");
    generateCommentaryButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            FanExperience fanExperience = new FanExperience(gameData, gameStatistics);
            fanExperience.generateLiveCommentary();
        }
    });
    commentaryPanel.add(generateCommentaryButton);

    // Initialize highlights panel
    highlightsPanel = new JPanel();
    JButton generateHighlightsButton = new JButton("Generate Game Highlights");
    generateHighlightsButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            FanExperience fanExperience = new FanExperience(gameData, gameStatistics);
            fanExperience.generateGameHighlights();
        }
    });
    highlightsPanel.add(generateHighlightsButton);

    // Set layout
    setLayout(new GridLayout(6, 2));

    // Add labels to frame
    add(homeScoreLabel);
    add(awayScoreLabel);
    add(gameTimeLabel);
    add(locationLabel);
    add(homeShotsOnGoalLabel);
    add(awayShotsOnGoalLabel);
    add(homePossessionLabel);
    add(awayPossessionLabel);
    add(homeCornersLabel);
    add(awayCornersLabel);

    // Add panels to frame
    add(commentaryPanel);
    add(highlightsPanel);

    // Set frame properties
    setTitle("Fan Experience");
    setSize(400, 300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setVisible(true);
}

public static void main(String[] args) {
    GameData gameData = new GameData(1, 2, 58, "Stadium");
    GameStatistics gameStatistics = new GameStatistics(10, 5, 60, 40, 8, 6);
    FanExperienceGUI fanExperienceGUI = new FanExperienceGUI(gameData, gameStatistics);
}
}